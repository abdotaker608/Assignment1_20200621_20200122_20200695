// FCAI – Object-Oriented Programming 1 – 2022 - Assignment 2
// Program Name: BigReal
// Last Modification Date:
// Author1 and ID and Group: Huda  ID: 20200621 (a, b, c, d, e, f, g)
// Author2 and ID and Group: Salma Gamal Ezat AbdelRazek  ID: 20210493 (h, i)
// Author3 and ID and Group: Laila Hesham Kandil  ID: 20210501 (j, k, l , m, n ,o ,p)
#include<bits/stdc++.h>
#include "BigDecimalIntClass.h"
using namespace std;
class BigReal{
private:
    string realnumber;
    bool checkValidInput(string input);
    BigDecimalInt fraction;
    int signs;
    BigDecimalInt num;
    int point=realnumber.find('.');
public:

    const BigDecimalInt &getFraction() const;
    const BigDecimalInt &getNum() const;
    int getSigns() const;
    BigReal (double realNumber = 0.0); // Default constructor
    BigReal (string realNumber);
    BigReal (BigDecimalInt bigInteger);
    BigReal (const BigReal& other); // Copy constructor
    BigReal (BigReal&& other); // Move constructor
    BigReal& operator= (BigReal& other); // Assignment operator
    BigReal& operator= (BigReal&& other); // Move assignment
    BigReal operator+ (BigReal& other);
    BigReal operator- (BigReal& other);
    bool operator< (BigReal& anotherReal);
    bool operator> (BigReal& anotherReal);
    bool operator== (BigReal& anotherReal);
    int size();
    int sign();
    friend ostream& operator << (ostream& out, BigReal& num);
    friend istream& operator >> (istream& out, BigReal& num);
};

