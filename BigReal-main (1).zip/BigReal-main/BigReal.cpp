#include "BigReal.h"
bool BigReal :: checkValidInput(string input)
{
    regex validInput("[-+]?([0-9]*[.])?[0-9]+");
    return regex_match(input, validInput);
}

// Default constructor
BigReal::BigReal(double realNumber): BigReal(to_string(realNumber)){
}
BigReal::BigReal(string realNumber) {
    realnumber=realNumber;
    int point=realNumber.find('.');
    num=BigDecimalInt(realNumber.substr(0,point));
    fraction=BigDecimalInt(realNumber.substr(point+1, realNumber.find_last_not_of('0') - point));
    signs=num.sign();
}
//
BigReal::BigReal(BigDecimalInt bigInteger) {
    num=bigInteger;
}
// Copy constructor
BigReal::BigReal(const BigReal &other) {
    realnumber = other.realnumber;
}
// Move constructor
BigReal::BigReal(BigReal &&other) {
    realnumber = other.realnumber;
    other.realnumber = "";
}
// Assignment operator
BigReal &BigReal::operator=(BigReal &other) {
    realnumber = other.realnumber;
}
// Move assignment
BigReal &BigReal::operator=(BigReal &&other) {
    if (this != &other) {
        realnumber = other.realnumber;
        other.realnumber = "";
    }
    return *this;
}

//addition operator
BigReal BigReal::operator+(BigReal &other) {
    BigReal result;
    int carry;
    auto number = num + other.getNum();
    auto decimal = fraction + other.getFraction();
    result.num = number;
    result.fraction = decimal;
    cout << result.num << endl;
    cout << result.fraction << endl;
    return BigReal();
}
//subtraction operator
BigReal BigReal::operator-(BigReal &other) {
    return BigReal();
}
//Less than operator
bool BigReal::operator<(BigReal& anotherReal){
    if(num < anotherReal.num){
        return true;
    }
    else if(num > anotherReal.getNum())
        return false;
    else if(num==anotherReal.getNum()){
        int maxSize = max(fraction.size(), anotherReal.fraction.size());
        string str = fraction.getNumber() + "0000000000000000";
        BigDecimalInt fr1 = BigDecimalInt(str.substr(0, maxSize));
        string str2 = anotherReal.fraction.getNumber() + "0000000000000000";
        BigDecimalInt fr2 = BigDecimalInt(str2.substr(0, maxSize));

        if(num.sign() == 1 && anotherReal.num.sign() == 1)
            return fr1<fr2;
        else if(num.sign() == 0 && anotherReal.num.sign() == 0)
            return fr1>fr2;
    }
    return false;
}
//Greater than operator
bool BigReal::operator>(BigReal& anotherReal) {
    if(num > anotherReal.num )
        return true;
    else if(num < anotherReal.num)
        return false;
    else if(num==anotherReal.getNum()){
        int maxSize = max(fraction.size(), anotherReal.fraction.size());
        string str = fraction.getNumber() + "0000000000000000";
        BigDecimalInt fr1 = BigDecimalInt(str.substr(0, maxSize));
        string str2 = anotherReal.fraction.getNumber() + "0000000000000000";
        BigDecimalInt fr2 = BigDecimalInt(str2.substr(0, maxSize));

        if(num.sign() == 1 && anotherReal.num.sign() == 1){
            if(fr1>fr2)
                return true;
            return false;
        }
        else if(num.sign() == 0 && anotherReal.num.sign() == 0)
            if(fr1<fr2){
                return true;
            }

            return false;
    }
    return false;
}
//Equal equal operator
bool BigReal::operator==(BigReal& anotherReal){
    if(num == anotherReal.num && fraction == anotherReal.fraction){
        return true;
    }

    else
        return false;
}
//Returns the size of the number
int BigReal::size(){
    return realnumber.size();
}

//Returns the sign of the number
int BigReal::sign() {
    //if + return 1
    //if - return -1
    return num.sign();
}

ostream& operator<<(ostream &out, BigReal& num) {
    out << num.realnumber;
    return out ;
}

istream& operator>>(istream &in, BigReal& num) {
    string temp;
    in >> temp;
    num.realnumber=temp;
    int point=temp.find('.');
    num.num=BigDecimalInt(temp.substr(0,point));
    num.fraction=BigDecimalInt(temp.substr(point+1, temp.find_last_not_of('0') - point));
    num.signs=num.sign();
    return in;
}

const BigDecimalInt &BigReal::getFraction() const {
    return fraction;
}

const BigDecimalInt &BigReal::getNum() const {
    return num;
}

int BigReal::getSigns() const {
    return signs;
}
