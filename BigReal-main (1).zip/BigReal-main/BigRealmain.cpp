#include<bits/stdc++.h>
#include"BigReal.h"
using namespace std;
int main() {
    BigReal num1;
    BigReal num2;
    cout<<"Please enter a number"<<endl;
    cin>>num1;
    cout<<"Please enter your second number"<<endl;
    cin>>num2;
    cout << num2.getNum() << endl;
    cout << num2.getFraction() << endl;
    cout<<num2.sign()<<endl;
    cout<<num1.size()<<endl;
    if (num1 < num2) {
        cout << num1 << " is smaller than " << num2 << endl;
    } else if (num1 > num2)
        cout << num1 << " is greater than " << num2 << endl;
    else if (num1 == num2) {
        cout << num1 << " is equal to " << num2 << endl;
    }
}